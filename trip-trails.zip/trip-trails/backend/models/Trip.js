const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    startLocation: { type: String, required: true },
    stops: [{ type: String }],
    endLocation: { type: String, required: true },
    expenses: Number,
    distance: Number,
    daysNights: Number,
    description: String,
    photos: [String],
}, { timestamps: true });

module.exports = mongoose.model('Trip', tripSchema);