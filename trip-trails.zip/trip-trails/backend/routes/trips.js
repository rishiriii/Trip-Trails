const express = require('express');
const Trip = require('../models/Trip');
const router = express.Router();

// Add a new trip
router.post('/', async (req, res) => {
    const newTrip = new Trip(req.body);
    try {
        const savedTrip = await newTrip.save();
        res.status(201).json(savedTrip);
    } catch (err) {
        res.status(500).json(err);
    }
});

// Get all trips for a user
router.get('/:userId', async (req, res) => {
    try {
        const trips = await Trip.find({ userId: req.params.userId });
        res.status(200).json(trips);
    } catch (err) {
        res.status(500).json(err);
    }
});

module.exports = router;