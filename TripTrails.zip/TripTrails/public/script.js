// public/script.js
async function loadTrips() {
  const response = await fetch('/trips');
  const trips = await response.json();

  const tripList = document.getElementById('trip-list');
  tripList.innerHTML = '';  // Clear existing content

  trips.forEach(trip => {
    const tripCard = document.createElement('div');
    tripCard.className = 'trip-card';
    tripCard.dataset.id = trip.id;
    tripCard.innerHTML = `
      <h3>${trip.title}</h3>
      <p>${trip.days} Days / ${trip.nights} Nights</p>
      <p>Cost: $${trip.expense}</p>
      <button class="delete-trip-btn" data-id="${trip.id}">Delete</button>
    `;

    tripCard.addEventListener('click', () => {
      window.location.href = `trip-details.html?id=${trip.id}`;
    });

    tripList.appendChild(tripCard);
  });

  // Add event listeners for the delete buttons
document.querySelectorAll('.delete-trip-btn').forEach(button => {
  button.addEventListener('click', async (event) => {
    event.stopPropagation(); // Prevent opening trip details when clicking delete
    const tripId = button.dataset.id;

    console.log(`Attempting to delete trip with ID: ${tripId}`); // Debug line

    try {
      const response = await fetch(`/trips/${tripId}`, { method: 'DELETE' });
      if (response.ok) {
        console.log('Trip deleted successfully');
        loadTrips();  // Refresh the trip list after deletion
      } else {
        console.error('Failed to delete trip');
      }
    } catch (error) {
      console.error('Error deleting trip:', error);
    }
    });
  });
}

loadTrips();
