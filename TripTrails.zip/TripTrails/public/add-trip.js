// public/add-trip.js
document.getElementById('add-trip-form').addEventListener('submit', async (event) => {
    event.preventDefault();
  
    // Gather form data
    const formData = new FormData(event.target);
    const newTrip = Object.fromEntries(formData.entries());
  
    // Send the new trip data to the server
    await fetch('/trips', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newTrip),
    });
  
    // Redirect back to homepage
    window.location.href = 'index.html';
  });
  