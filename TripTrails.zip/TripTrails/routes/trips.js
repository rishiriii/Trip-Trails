// routes/trips.js
const express = require('express');
const router = express.Router();

let trips = [
  { id: 1, title: 'Trip to Bali', start: 'New York', end: 'Bali', days: 7, nights: 6, expense: 1500, description: 'A beautiful trip to Bali.' },
  { id: 2, title: 'Trip to Paris', start: 'Los Angeles', end: 'Paris', days: 5, nights: 4, expense: 1200, description: 'Romantic getaway to Paris.' }
];

// Route to get all trips
router.get('/', (req, res) => {
  res.json(trips);
});

// Route to add a new trip
router.post('/', (req, res) => {
    const newTrip = {
      id: trips.length + 1,
      title: req.body.title,
      start: req.body.start,
      end: req.body.end,
      days: parseInt(req.body.days),
      nights: parseInt(req.body.nights),
      expense: parseFloat(req.body.expense),
      description: req.body.description
    };
    trips.push(newTrip);
    res.status(201).json(newTrip);
  });
  

// Route to get a specific trip by ID
router.get('/:id', (req, res) => {
  const tripId = parseInt(req.params.id, 10);
  const trip = trips.find(t => t.id === tripId);

  if (trip) {
    res.json(trip);
  } else {
    res.status(404).json({ message: 'Trip not found' });
  }
});

router.delete('/:id', (req, res) => {
    const tripId = parseInt(req.params.id, 10);
    const tripIndex = trips.findIndex(t => t.id === tripId);
  
    if (tripIndex !== -1) {
      trips.splice(tripIndex, 1);  // Remove the trip from the array
      res.status(200).json({ message: 'Trip deleted successfully' });
    } else {
      res.status(404).json({ message: 'Trip not found' });
    }
  });
  

module.exports = router;
